SET NAMES 'utf8';

